const menuToggle = document.getElementById('menu-toggle');
const nav = document.querySelector('.main-nav');

menuToggle.addEventListener('click', () => {
  nav.classList.toggle('active');
});

function showAlert() {
  const alert = document.getElementById('alert');
  alert.style.display = 'block';
  setTimeout(() => alert.style.display = 'none', 3000);
}